﻿using Projet2_Praya.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projet2_Praya.ViewModels
{
    public class CreationProjetViewModel
    {
        public projet projet { get; set; }
        //public resp_projet resp_Projet { get; set; }
        // public List<type_projet> TypeProjets  { get ; set; }
        // public type_projet type_Projet { get; set; }
    }
}