﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projet2_Praya.Models
{
    public class DisplayInformationCatalogue
    {
        public int Id_projet { get; set; }
        public string Libelle { get; set; }
        public string Description { get; set; }
        public int Id_media { get; set; }
        public string Lib_image { get; set; }
       
    }
}